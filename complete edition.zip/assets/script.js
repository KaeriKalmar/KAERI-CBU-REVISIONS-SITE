// === CONFIGURATION ===

// Access codes allowed per course-term
const fullAccessCodes = {
  "BI110_T1": ["BI110T1_2025","BI110-cbu", "BI110T1_A"],
  "BI110_T2": ["BI110T2_2025", "BI110T2_A"],
  "BI110_T3": ["BI110T3_2025", "BI110T3_A"],
  "CS110_T1": ["CS110T1_2025", "CS110T1_A"],
  "CS110_T2": ["CS110T2_2025", "CS110T2_A"],
  "CS110_T3": ["CS110T3_2025", "CS110T3_A"]
};

// Permanently blocked codes
const forceRevokeList = ["BI110-cbu", "BI110T1_CODE_A"];

// Used codes (shared across sessions)
let usedAccessCodes = ["BI110T1_CODE_A"];

// Expiry settings
const EXPIRES_IN_DAYS = 20;
const MILLISECONDS_IN_20_DAYS = EXPIRES_IN_DAYS * 24 * 60 * 60 * 1000;

// Unique device ID
const deviceId = btoa(navigator.userAgent + screen.width + screen.height);

// === QUIZ STATE HOLDERS ===
let allMcqData = [], allShortData = [], allEssayData = [], allFlashcards = {};
let currentMcqData = [], currentShortData = [], currentEssayData = [], currentFlashcardTopics = {};

let currentQuizType = null, currentQuestionIndex = 0, currentScore = 0, currentQuizData = [];
let currentCourse = null, currentTerm = null, currentTermKey = null;

// === ON LOAD ===
window.onload = () => {
  // Identify course + term
  currentCourse = document.body.getAttribute('data-course');
  currentTerm = document.body.getAttribute('data-term');
  currentTermKey = `${currentCourse}_${currentTerm}`;

  if (!currentCourse || !currentTerm) {
    document.querySelector('.quiz-container').innerHTML = "<p style='color:red'>Missing course or term.</p>";
    return;
  }

  // Load existing global used access codes
  try {
    const storedUsed = localStorage.getItem("globalUsedAccessCodes");
    if (storedUsed) usedAccessCodes = [...new Set([...usedAccessCodes, ...JSON.parse(storedUsed)])];
  } catch {
    usedAccessCodes = [];
  }

  // Force-blocked codes
  forceRevokeList.forEach(code => {
    if (!usedAccessCodes.includes(code)) usedAccessCodes.push(code);
  });
  localStorage.setItem("globalUsedAccessCodes", JSON.stringify(usedAccessCodes));

  // Load global quiz datasets
  allMcqData = typeof mcqData !== 'undefined' ? mcqData : [];
  allShortData = typeof shortData !== 'undefined' ? shortData : [];
  allEssayData = typeof essayData !== 'undefined' ? essayData : [];
  allFlashcards = typeof flashcards !== 'undefined' ? flashcards : {};

  // Filter by term
  currentMcqData = filterDataByCourseAndTerm(allMcqData, currentCourse, currentTerm);
  currentShortData = filterDataByCourseAndTerm(allShortData, currentCourse, currentTerm);
  currentEssayData = filterDataByCourseAndTerm(allEssayData, currentCourse, currentTerm);
  currentFlashcardTopics = filterFlashcardsByCourseAndTerm(allFlashcards, currentCourse, currentTerm);

  // Access check
  const storedCode = localStorage.getItem("accessCode");
  const storedExpiry = parseInt(localStorage.getItem("accessCodeExpires") || "0");
  const storedDeviceId = localStorage.getItem("accessDeviceId");
  const storedUnlockedTerms = JSON.parse(localStorage.getItem("unlockedTerms") || "[]");

  if (storedCode && forceRevokeList.includes(storedCode)) {
    forceRevoke(storedCode);
    return;
  }

  if (
    storedCode &&
    usedAccessCodes.includes(storedCode) &&
    (fullAccessCodes[currentTermKey] || []).includes(storedCode) &&
    Date.now() < storedExpiry &&
    storedDeviceId === deviceId &&
    storedUnlockedTerms.includes(currentTermKey)
  ) {
    updateModeBanner("✅ Full Access Mode");
    const daysLeft = Math.ceil((storedExpiry - Date.now()) / (24 * 60 * 60 * 1000));
    showAppNotification(`✅ Full Access — expires in ${daysLeft} day(s).`, "success");
    clearDemoLocks();
  } else {
    // Expired or wrong device
    if (storedCode && Date.now() >= storedExpiry) {
      showAppNotification("⚠️ Access code expired.", "warning");
      clearStoredCode();
    } else if (storedCode && storedDeviceId !== deviceId) {
      showAppNotification("⚠️ Code bound to another device.", "warning");
      clearStoredCode();
    }
    promptForCode();

    // Auto-start demo if MCQs exist
    setTimeout(() => {
      if (currentMcqData.length > 0) renderQuiz();
    }, 500);
  }
};

// === HELPERS FOR FILTERING ===
function filterDataByCourseAndTerm(dataArray, course, term) {
  return Array.isArray(dataArray) ? dataArray.filter(q => q.course === course && q.term === term) : [];
}

function filterFlashcardsByCourseAndTerm(flashcardObj, course, term) {
  const filtered = {};
  for (const topic in flashcardObj) {
    const cards = flashcardObj[topic].filter(f => f.course === course && f.term === term);
    if (cards.length) filtered[topic] = cards;
  }
  return filtered;
}

// === CODE HANDLING ===
function promptForCode() {
  const code = prompt(`Enter Access Code for ${currentCourse} ${currentTerm} (or leave blank for demo):`);
  const validCodes = fullAccessCodes[currentTermKey] || [];

  if (!code) {
    updateModeBanner("🔒 Demo Mode: Limited Access");
    return;
  }

  if (forceRevokeList.includes(code)) {
    forceRevoke(code);
    return;
  }

  if (!validCodes.includes(code)) {
    alert("❌ Invalid code.");
    updateModeBanner("🔒 Demo Mode: Limited Access");
    return;
  }

  if (usedAccessCodes.includes(code)) {
    alert("❌ Code has already been used.");
    updateModeBanner("🔒 Demo Mode: Limited Access");
    return;
  }

  usedAccessCodes.push(code);
  localStorage.setItem("globalUsedAccessCodes", JSON.stringify(usedAccessCodes));

  localStorage.setItem("accessCode", code);
  localStorage.setItem("accessCodeExpires", Date.now() + MILLISECONDS_IN_20_DAYS);
  localStorage.setItem("accessDeviceId", deviceId);

  const unlocked = JSON.parse(localStorage.getItem("unlockedTerms") || "[]");
  unlocked.push(currentTermKey);
  localStorage.setItem("unlockedTerms", JSON.stringify(unlocked));

  updateModeBanner("✅ Full Access Mode");
  showAppNotification("✅ Access Granted", "success");
  clearDemoLocks();
}

function clearStoredCode() {
  localStorage.removeItem("accessCode");
  localStorage.removeItem("accessCodeExpires");
  localStorage.removeItem("accessDeviceId");
  localStorage.removeItem("unlockedTerms");
}

function hasFullAccessForCurrentTerm() {
  const unlocked = JSON.parse(localStorage.getItem("unlockedTerms") || "[]");
  return unlocked.includes(currentTermKey);
}

function blockDemo(quizType) {
  if (hasFullAccessForCurrentTerm()) return false;
  const key = `${currentTermKey}_${quizType}_Attempts`;
  let count = parseInt(localStorage.getItem(key) || "0");
  if (count >= 1) {
    alert(`Demo limit reached for ${quizType}.`);
    return true;
  }
  localStorage.setItem(key, count + 1);
  return false;
}

function forceRevoke(code) {
  alert("❌ This code is revoked.");
  clearStoredCode();
  updateModeBanner("🔒 Revoked");
}
// === QUIZ UTILITIES ===
function shuffle(arr) {
  let current = arr.length, temp, rand;
  while (current !== 0) {
    rand = Math.floor(Math.random() * current);
    current--;
    [arr[current], arr[rand]] = [arr[rand], arr[current]];
  }
  return arr;
}

function updateModeBanner(message) {
  const banner = document.getElementById("mode-banner");
  if (banner) {
    banner.textContent = message;
    banner.className = message.includes("Full") ? "mode-banner-full" : "mode-banner-demo";
  }
}

function showAppNotification(msg, type = "info") {
  const note = document.querySelector(".app-notification");
  if (!note) return;
  note.textContent = msg;
  note.className = `app-notification show ${type}`;
  setTimeout(() => note.classList.remove("show"), 5000);
}

function updateProgress(current, total) {
  const fill = document.getElementById("progress-fill");
  const text = document.getElementById("progress-text");
  if (fill && text) {
    const percent = total === 0 ? 0 : Math.floor((current / total) * 100);
    fill.style.width = `${percent}%`;
    text.textContent = `Progress: ${current} of ${total}`;
  }
}

// === QUIZ INITIALIZATION ===
function initializeQuiz(quizData, type) {
  let limit = hasFullAccessForCurrentTerm() ? 10 : (type === 'mcq' ? 3 : type === 'shortAnswer' ? 2 : type === 'essay' ? 1 : 0);
  currentQuizData = shuffle([...quizData]).slice(0, limit || quizData.length);
  currentQuizType = type;
  currentQuestionIndex = 0;
  currentScore = 0;
  document.getElementById("result").innerHTML = "";

  if (!currentQuizData.length) {
    document.getElementById("quiz-form").innerHTML = "<p>No questions available.</p>";
    updateProgress(0, 0);
    return false;
  }

  updateProgress(currentQuestionIndex, currentQuizData.length);
  return true;
}

function getQuestionMetadata(item) {
  let html = "";
  if (item.course && item.term) html += `<span><strong>Course:</strong> ${item.course} ${item.term}</span> `;
  if (item.topic) html += `<span><strong>Topic:</strong> ${item.topic}</span> `;
  if (item.year) html += `<span><strong>Year:</strong> ${item.year}</span> `;
  if (item.tag) {
    html += `<span><strong>Tag:</strong> ${item.tag.split(',').map(t => `<span class="tag">${t}</span>`).join(" ")}</span>`;
  }
  return `<div class="question-metadata">${html}</div>`;
}

// === MCQ MODE ===
function renderQuiz() {
  if (blockDemo('mcq')) return;
  const container = document.getElementById("quiz-form");
  container.innerHTML = "";
  container.scrollIntoView({ behavior: "smooth" });
  if (!initializeQuiz(currentMcqData, 'mcq')) return;
  displayMcqQuestion();
}

function displayMcqQuestion() {
  const q = currentQuizData[currentQuestionIndex];
  const container = document.getElementById("quiz-form");
  updateProgress(currentQuestionIndex, currentQuizData.length);

  if (!q) {
    showFinalMcqScore();
    return;
  }

  let html = `${getQuestionMetadata(q)}
    <div class="question-box">
      <p><strong>Q${currentQuestionIndex + 1}:</strong> ${q.q}</p>
      <div class="options">`;

  q.options.forEach((opt, idx) => {
    html += `<label><input type="radio" name="mcq" value="${idx}"> ${String.fromCharCode(65 + idx)}. ${opt}</label><br>`;
  });

  html += `</div><button onclick="checkMcqAnswer()">Submit</button></div>`;
  container.innerHTML = html;
}

function checkMcqAnswer() {
  const selected = document.querySelector('input[name="mcq"]:checked');
  const resultDiv = document.getElementById("result");
  if (!selected) return alert("Select an option.");
  const userAnswer = parseInt(selected.value);
  const q = currentQuizData[currentQuestionIndex];
  resultDiv.innerHTML = "";

  if (userAnswer === q.correct) {
    currentScore++;
    resultDiv.innerHTML = "<p class='feedback-message feedback-correct'>✔️ Correct!</p>";
  } else {
    resultDiv.innerHTML = `<p class='feedback-message feedback-incorrect'>❌ Incorrect. Answer: ${String.fromCharCode(65 + q.correct)}. ${q.options[q.correct]}</p>`;
  }

  resultDiv.innerHTML += `<div class="explanation-box">${q.explanation || ''}</div>`;
  const next = document.createElement("button");
  next.textContent = currentQuestionIndex < currentQuizData.length - 1 ? "Next ➡️" : "Finish Quiz";
  next.onclick = displayMcqQuestion;
  resultDiv.appendChild(next);
  document.querySelectorAll('input[name="mcq"]').forEach(i => i.disabled = true);
  currentQuestionIndex++;
}

function showFinalMcqScore() {
  const container = document.getElementById("quiz-form");
  const score = Math.round((currentScore / currentQuizData.length) * 100);
  const comment = score >= 90 ? "🎉 Excellent!" : score >= 70 ? "✅ Good!" : "❌ Try Again!";
  container.innerHTML = `<h2>Finished!</h2><p>Score: ${currentScore}/${currentQuizData.length} (${score}%)</p><p>${comment}</p><button onclick="renderQuiz()">🔁 Retry</button>`;
  updateProgress(currentQuizData.length, currentQuizData.length);
}

// === SHORT ANSWER MODE ===
function renderShortAnswers() {
  if (blockDemo('shortAnswer')) return;
  const container = document.getElementById("quiz-form");
  container.innerHTML = "";
  container.scrollIntoView({ behavior: "smooth" });
  if (!initializeQuiz(currentShortData, 'shortAnswer')) return;
  displayShortAnswerQuestion();
}

function displayShortAnswerQuestion() {
  const q = currentQuizData[currentQuestionIndex];
  const container = document.getElementById("quiz-form");
  updateProgress(currentQuestionIndex, currentQuizData.length);

  if (!q) {
    showFinalShortAnswerScore();
    return;
  }

  container.innerHTML = `
    ${getQuestionMetadata(q)}
    <div class="question-box">
      <p><strong>Q${currentQuestionIndex + 1}:</strong> ${q.q}</p>
      <textarea id="short-answer-input" placeholder="Type answer..."></textarea><br>
      <button onclick="checkShortAnswer()">Submit</button>
    </div>
  `;
}

function checkShortAnswer() {
  const userAnswer = document.getElementById("short-answer-input").value.toLowerCase();
  const q = currentQuizData[currentQuestionIndex];
  const keywords = Array.isArray(q.keywords) ? q.keywords.map(k => k.toLowerCase()) : [];
  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = "";

  const match = keywords.some(k => userAnswer.includes(k));
  if (match) {
    currentScore++;
    resultDiv.innerHTML = "<p class='feedback-message feedback-correct'>✔️ Good!</p>";
  } else {
    resultDiv.innerHTML = `<p class='feedback-message feedback-incorrect'>❌ Expected: ${keywords.join(", ")}</p>`;
  }

  resultDiv.innerHTML += `<div class="explanation-box">${q.explanation || ''}</div>`;
  const next = document.createElement("button");
  next.textContent = currentQuestionIndex < currentQuizData.length - 1 ? "Next ➡️" : "Finish Quiz";
  next.onclick = displayShortAnswerQuestion;
  resultDiv.appendChild(next);
  document.getElementById("short-answer-input").disabled = true;
  currentQuestionIndex++;
}

function showFinalShortAnswerScore() {
  const container = document.getElementById("quiz-form");
  const score = Math.round((currentScore / currentQuizData.length) * 100);
  const comment = score >= 90 ? "🎉 Excellent!" : score >= 70 ? "✅ Good!" : "❌ Try Again!";
  container.innerHTML = `<h2>Completed!</h2><p>Score: ${currentScore}/${currentQuizData.length} (${score}%)</p><p>${comment}</p><button onclick="renderShortAnswers()">🔁 Retry</button>`;
  updateProgress(currentQuizData.length, currentQuizData.length);
}
// === ESSAY SIMULATION MODE ===
let currentEssay = null;
let currentStepIndex = 0;
let essayScore = 0;

function renderEssaySimulation() {
  if (blockDemo('essay')) return;
  const container = document.getElementById("quiz-form");
  container.innerHTML = "";
  document.getElementById("result").innerHTML = "";
  container.scrollIntoView({ behavior: "smooth" });

  if (!initializeQuiz(currentEssayData, 'essay')) return;

  currentEssay = currentQuizData[0];
  currentStepIndex = 0;
  essayScore = 0;

  showEssayStep(currentStepIndex);
}

function showEssayStep(index) {
  const step = currentEssay.steps[index];
  const container = document.getElementById("quiz-form");
  updateProgress(index, currentEssay.steps.length);

  if (!step) {
    showFinalEssayScore();
    return;
  }

  let html = `
    ${getQuestionMetadata(currentEssay)}
    <div class="question-box">
      <h3>${currentEssay.title} (Step ${index + 1} of ${currentEssay.steps.length})</h3>
      <p><strong>Q:</strong> ${step.q}</p>
      <div class="options">`;

  step.options.forEach((opt, idx) => {
    html += `<label><input type="radio" name="step" value="${idx}"> ${String.fromCharCode(65 + idx)}. ${opt}</label><br>`;
  });

  html += `</div><button onclick="checkEssayStep()">Submit</button></div>`;
  container.innerHTML = html;
  document.getElementById("result").innerHTML = "";
}

function checkEssayStep() {
  const selected = document.querySelector('input[name="step"]:checked');
  const resultDiv = document.getElementById("result");
  if (!selected) return alert("Select an answer.");
  const answer = parseInt(selected.value);
  const step = currentEssay.steps[currentStepIndex];

  if (answer === step.correct) {
    essayScore++;
    resultDiv.innerHTML = "<p class='feedback-message feedback-correct'>✔️ Correct!</p>";
  } else {
    resultDiv.innerHTML = `<p class='feedback-message feedback-incorrect'>❌ Incorrect. Correct: ${String.fromCharCode(65 + step.correct)}. ${step.options[step.correct]}</p>`;
  }

  resultDiv.innerHTML += `<div class="explanation-box">${step.explanation || ''}</div>`;

  const next = document.createElement("button");
  next.textContent = currentStepIndex < currentEssay.steps.length - 1 ? "Next ➡️" : "Finish";
  next.onclick = () => {
    currentStepIndex++;
    showEssayStep(currentStepIndex);
  };
  resultDiv.appendChild(next);
  document.querySelectorAll('input[name="step"]').forEach(i => i.disabled = true);
}

function showFinalEssayScore() {
  const container = document.getElementById("quiz-form");
  const percent = Math.round((essayScore / currentEssay.steps.length) * 100);
  const comment = percent >= 90 ? "🎯 Well done!" : percent >= 70 ? "✅ Good!" : "❌ Try again!";
  container.innerHTML = `<h2>Essay Complete</h2><p>Score: ${essayScore}/${currentEssay.steps.length} (${percent}%)</p><p>${comment}</p><button onclick="renderEssaySimulation()">🔁 Retry</button>`;
  updateProgress(currentEssay.steps.length, currentEssay.steps.length);
}

// === FLASHCARDS MODE ===
let currentFlashcardTopic = null;
let currentFlashcards = [];
let currentCardIndex = 0;
let isCardFront = true;

function renderFlashcardTopics() {
  if (blockDemo('flashcard')) {
    document.getElementById("quiz-form").innerHTML = "<p>🔒 Locked in Demo Mode</p>";
    return;
  }
  const container = document.getElementById("quiz-form");
  container.innerHTML = "";
  document.getElementById("result").innerHTML = "";
  container.scrollIntoView({ behavior: "smooth" });

  currentQuizType = 'flashcard';

  const wrapper = document.createElement("div");
  wrapper.className = "flashcard-topics-wrapper";

  if (!Object.keys(currentFlashcardTopics).length) {
    wrapper.innerHTML = "<p>No flashcards available.</p>";
  } else {
    for (const topic in currentFlashcardTopics) {
      const btn = document.createElement("button");
      btn.textContent = topic;
      btn.onclick = () => startFlashcards(topic);
      wrapper.appendChild(btn);
    }
  }

  container.appendChild(wrapper);
}

function startFlashcards(topic) {
  currentFlashcardTopic = topic;
  currentFlashcards = currentFlashcardTopics[topic];
  currentCardIndex = 0;
  isCardFront = true;
  displayFlashcard();
}

function displayFlashcard() {
  const card = currentFlashcards[currentCardIndex];
  const container = document.getElementById("quiz-form");
  updateProgress(currentCardIndex + 1, currentFlashcards.length);

  container.innerHTML = `
    <div class="flashcard-nav">
      <button onclick="prevFlashcard()" ${currentCardIndex === 0 ? "disabled" : ""}>⬅️ Prev</button>
      <span>Card ${currentCardIndex + 1} / ${currentFlashcards.length}</span>
      <button onclick="nextFlashcard()" ${currentCardIndex === currentFlashcards.length - 1 ? "disabled" : ""}>Next ➡️</button>
    </div>
    <div class="flashcard-wrapper">
      <div class="flashcard ${isCardFront ? "front-active" : "back-active"}" onclick="flipCard()">
        <div class="card-face card-front">${card.front}</div>
        <div class="card-face card-back">${card.back}</div>
      </div>
    </div>
    <button class="flip-button" onclick="flipCard()">🔄 Flip</button>
    <button class="back-to-topics-button" onclick="renderFlashcardTopics()">⬅️ Back</button>
  `;
}

function flipCard() {
  isCardFront = !isCardFront;
  displayFlashcard();
}

function nextFlashcard() {
  if (currentCardIndex < currentFlashcards.length - 1) {
    currentCardIndex++;
    isCardFront = true;
    displayFlashcard();
  }
}

function prevFlashcard() {
  if (currentCardIndex > 0) {
    currentCardIndex--;
    isCardFront = true;
    displayFlashcard();
  }
}

// === FINAL UTILITIES ===
function clearDemoLocks() {
  ["mcq", "shortAnswer", "essay", "flashcard"].forEach(type => {
    localStorage.removeItem(`${currentTermKey}_${type}_Attempts`);
  });
}

function blockDemo(type) {
  if (hasFullAccessForCurrentTerm()) return false;
  const key = `${currentTermKey}_${type}_Attempts`;
  const attempts = parseInt(localStorage.getItem(key) || "0");
  if (attempts >= 1) {
    alert(`🔒 Limit reached for ${type}. Upgrade for full access.`);
    return true;
  }
  localStorage.setItem(key, attempts + 1);
  return false;
}

function hasFullAccessForCurrentTerm() {
  const code = localStorage.getItem("accessCode");
  const expiry = parseInt(localStorage.getItem("accessCodeExpires") || "0");
  const id = localStorage.getItem("accessDeviceId");
  const unlocked = JSON.parse(localStorage.getItem("unlockedTerms") || "[]");
  return (
    code &&
    usedAccessCodes.includes(code) &&
    Date.now() < expiry &&
    id === deviceId &&
    unlocked.includes(currentTermKey)
  );
}