const mcqData = [
    {
        q: "Which organelle is responsible for protein synthesis?",
        options: [
            "Mitochondria",
            "Golgi apparatus",
            "Ribosomes",
            "Endoplasmic reticulum"
        ],
        correct: 2, // Ribosomes
        explanation: "Ribosomes are the cellular structures where protein synthesis occurs, reading mRNA to assemble amino acids.",
        course: "BI110",
        term: "T1",
        topic: "Cell Biology",
        tag: "⭐,❗"
    },
    {
        q: "What is the primary function of the mitochondria?",
        options: [
            "Photosynthesis",
            "Protein synthesis",
            "ATP production",
            "Lipid storage"
        ],
        correct: 2, // ATP production
        explanation: "Mitochondria generate ATP through cellular respiration, earning them the nickname 'powerhouse of the cell'.",
        course: "BI110",
        term: "T1",
        topic: "Cell Biology"
    },
    {
        q: "Which of these is NOT a phase of mitosis?",
        options: [
            "Prophase",
            "Metaphase",
            "Interphase",
            "Telophase"
        ],
        correct: 2, // Interphase
        explanation: "Interphase is the cell's growth phase between divisions, while prophase, metaphase, and telophase are stages of mitosis.",
        course: "BI110",
        term: "T1",
        topic: "Cell Division"
    },
    {
        q: "In DNA, adenine always pairs with:",
        options: [
            "Guanine",
            "Cytosine",
            "Thymine",
            "Uracil"
        ],
        correct: 2, // Thymine
        explanation: "Adenine pairs with thymine in DNA (and with uracil in RNA) through hydrogen bonding.",
        course: "BI110",
        term: "T1",
        topic: "Genetics",
        tag: "🟩"
    },
    {
        q: "Which process produces the most ATP per glucose molecule?",
        options: [
            "Glycolysis",
            "Fermentation",
            "Krebs cycle",
            "Electron transport chain"
        ],
        correct: 3, // Electron transport chain
        explanation: "The electron transport chain produces 32-34 ATP molecules, far more than other stages of cellular respiration.",
        course: "BI110",
        term: "T1",
        topic: "Cellular Respiration"
    },
    {
        q: "What is the purpose of meiosis?",
        options: [
            "Cellular repair",
            "Growth of organisms",
            "Production of gametes",
            "Asexual reproduction"
        ],
        correct: 2, // Production of gametes
        explanation: "Meiosis reduces chromosome number by half to produce haploid gametes (sperm and egg cells).",
        course: "BI110",
        term: "T1",
        topic: "Genetics"
    },
    {
        q: "Which molecule carries genetic information from DNA to ribosomes?",
        options: [
            "tRNA",
            "mRNA",
            "rRNA",
            "DNA polymerase"
        ],
        correct: 1, // mRNA
        explanation: "Messenger RNA (mRNA) carries the genetic code from DNA in the nucleus to ribosomes for protein synthesis.",
        course: "BI110",
        term: "T1",
        topic: "Molecular Biology",
        tag: "🔄"
    },
    {
        q: "What is the function of enzymes in biological reactions?",
        options: [
            "Provide energy",
            "Act as substrates",
            "Lower activation energy",
            "Change reaction equilibrium"
        ],
        correct: 2, // Lower activation energy
        explanation: "Enzymes are biological catalysts that speed up reactions by reducing the activation energy needed.",
        course: "BI110",
        term: "T1",
        topic: "Biochemistry"
    },
    {
        q: "Which blood vessels carry oxygenated blood away from the heart?",
        options: [
            "Veins",
            "Arteries",
            "Capillaries",
            "Venules"
        ],
        correct: 1, // Arteries
        explanation: "Arteries carry oxygen-rich blood from the heart, while veins return oxygen-poor blood (except pulmonary vessels).",
        course: "BI110",
        term: "T1",
        topic: "Circulatory System"
    },
    {
        q: "What is the primary function of the nervous system?",
        options: [
            "Structural support",
            "Rapid communication",
            "Nutrient absorption",
            "Waste elimination"
        ],
        correct: 1, // Rapid communication
        explanation: "The nervous system uses electrical and chemical signals for fast coordination of body functions.",
        course: "BI110",
        term: "T1",
        topic: "Nervous System",
        tag: "⭐"
    }
];