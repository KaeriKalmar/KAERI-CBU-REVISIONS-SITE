const flashcards = {
    "Cell Biology": [
        {
            front: "What is the powerhouse of the cell?",
            back: "Mitochondria",
            course: "BI110",
            term: "T1",
            explanation: "Mitochondria generate ATP through cellular respiration."
        },
        {
            front: "What is the function of ribosomes?",
            back: "Protein synthesis",
            course: "BI110",
            term: "T1",
            explanation: "Ribosomes read mRNA and assemble amino acids into proteins."
        }
    ],
    "Genetics": [
        {
            front: "What does DNA stand for?",
            back: "Deoxyribonucleic Acid",
            course: "BI110",
            term: "T1",
            explanation: "DNA carries genetic instructions for development and function."
        },
        {
            front: "What are the four nitrogenous bases in DNA?",
            back: "Adenine, Thymine, Cytosine, Guanine (A-T, C-G)",
            course: "BI110",
            term: "T1",
            explanation: "These bases form complementary pairs in the DNA double helix."
        }
    ],
    "Microbiology": [
        {
            front: "What are the three main shapes of bacteria?",
            back: "Cocci (spherical), Bacilli (rod-shaped), Spirilla (spiral)",
            course: "BI110",
            term: "T1",
            explanation: "Bacterial morphology is important for identification."
        },
        {
            front: "What is the difference between gram-positive and gram-negative bacteria?",
            back: "Gram-positive have thick peptidoglycan layer, gram-negative have thin layer with outer membrane",
            course: "BI110",
            term: "T1",
            explanation: "This affects antibiotic susceptibility and staining."
        }
    ]
};